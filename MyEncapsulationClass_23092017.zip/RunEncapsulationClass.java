package com.c2n.corejava.encapsulation;

public class RunEncapsulationClass { // class declaration
public static void main(String[] args) { // main() method declaration
	MyEncapsulationClass myEncapsulationClass = new MyEncapsulationClass(); // Instantation(Instanting object), Creating object for MyEncapsulationClass.java
	myEncapsulationClass.setStr("Priya");
	myEncapsulationClass.setNumber(189);
	myEncapsulationClass.setTest("RunTest");
	int outPutInt=myEncapsulationClass.getNumber();
	//String outPut=myEncapsulationClass.getStr();
	System.out.println(myEncapsulationClass.getStr());
	System.out.println(outPutInt);
	System.out.println(myEncapsulationClass.getTest());
	String s=myEncapsulationClass.getAccessMe();
	System.out.println(s);
} // end of main() method
}
