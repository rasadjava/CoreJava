package com.c2n.corejava.encapsulation;

public class MyEncapsulationClass { // class declaration
	public String str; // instant variable or Global variable of String type
	public int number; // instant variable or Global variable of int type
	public String test = "TestMe";
	private String accessMe = "AccessMe";

	public String getAccessMe() {
		return accessMe;
	}

	public void setAccessMe(String accessMe) {
		this.accessMe = accessMe;
	}

	public String getTest() {
		return test;
	}

	public void setTest(String test) {
		this.test = test;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public void setStr(String string) { // setter method
		this.str = string;
	} // end of setter method

	public String getStr() { // getter method
		System.out.println("Getter Method stuff: " + str);
		return str;
	} // end of getter method
}
