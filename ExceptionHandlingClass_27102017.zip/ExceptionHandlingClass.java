package com.c2n.corejava.ExceptionHandling;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ExceptionHandlingClass {

	public static void main(String[] args) {
		ExceptionHandlingClass exceptionHandlingClass=new ExceptionHandlingClass();
		try {
			exceptionHandlingClass.myExceptionsMethod1();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		exceptionHandlingClass.myExceptionsMethod2();
		exceptionHandlingClass.myExceptionsMethod3();
	}
	
	public void myExceptionsMethod1() throws IOException {
		System.out.println("####Start_1####");
		File file=new File("D:\\C2N_Related\\Clasess\\CoreJava\\ExceptionFile.txt");
		FileReader fileReader=new FileReader(file);
		char[] letters=new char[25];
		fileReader.read(letters);
		for(char let: letters) {
			System.out.print(let);
		}
		System.out.println("####End_1####");
	}
	
	public void myExceptionsMethod2() {
		System.out.println("####Start_2####");
		File file=new File("D:\\C2N_Related\\Clasess\\CoreJava\\ExceptionFile.txt");
		try {
			FileReader fileReader=new FileReader(file);
			System.out.println("####End_2####");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//System.out.println(e);
			System.out.println("####End_22####");
		}
	}
	
	public void myExceptionsMethod3() {
		System.out.println("####Start_2####");
		File file=new File("D:\\C2N_Related\\Clasess\\CoreJava\\ExceptionFile.txt");
		try {
			FileReader fileReader=new FileReader(file);
			char[] letters=new char[50];
			fileReader.read(letters);
			for(char let: letters) {
				System.out.print(let);
			}
			int i=3/0;
			System.out.println("####End_2####");
		}
		catch (FileNotFoundException e) {
			//e.printStackTrace();
			//System.out.println(e);
			System.out.println("####End_22####FileNotFoundException");
		}catch (IOException e) {
			//e.printStackTrace();
			//System.out.println(e);
			System.out.println("####End_22####IOException");
		}catch (ArithmeticException e) {
			//e.printStackTrace();
			//System.out.println(e);
			System.out.println("####End_22####ArithmeticException");
		}
		catch (Exception e) {
			//e.printStackTrace();
			//System.out.println(e);
			System.out.println("####End_22####Exception");
		}catch (Throwable e) {
			//e.printStackTrace();
			//System.out.println(e);
			System.out.println("####End_22####Throwable");
		}
		finally {
			System.out.println("####End_22####Finally,,,,");
		}
	}


}
