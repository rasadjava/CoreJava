package com.c2n.corejava.abstraction;

public abstract class MyAbstractClass {
	public void IamNotAbstractMethod() {
		System.out.println("Non-abstract method");
	}

	public abstract void IamAbstractMethod();
}
