package com.c2n.corejava.abstraction;

public class RunAbstractionImplimentation {

	public static void main(String[] args) {
		UseAbstractClass useAbstractClass = new UseAbstractClass();
		useAbstractClass.IamAbstractMethod();
		UseAbstractClass1 useAbstractClass1 = new UseAbstractClass1();
		useAbstractClass1.IamAbstractMethod();
		UseAbstractClass2 useAbstractClass2 = new UseAbstractClass2();
		useAbstractClass2.IamAbstractMethod();
		System.out.println("########################");
		MyAbstractClass myAbstractClass = new UseAbstractClass();
		myAbstractClass.IamAbstractMethod();
		MyAbstractClass myAbstractClass1 = new UseAbstractClass1();
		myAbstractClass1.IamAbstractMethod();
		MyAbstractClass myAbstractClass2 = new UseAbstractClass2();
		myAbstractClass2.IamAbstractMethod();
	}

}
