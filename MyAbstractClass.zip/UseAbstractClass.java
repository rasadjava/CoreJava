package com.c2n.corejava.abstraction;

public class UseAbstractClass extends MyAbstractClass {

	public void IamAbstractMethod() {
		System.out.println("I am Abstract Method of UseAbstractClass");
	}

	public void myMethod() {
		System.out.println("I am MyMethod");
	}
}
