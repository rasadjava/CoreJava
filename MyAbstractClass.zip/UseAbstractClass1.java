package com.c2n.corejava.abstraction;

public class UseAbstractClass1 extends MyAbstractClass{
public void IamAbstractMethod() {
	System.out.println("I am Abstract Method of UseAbstractClass1");
}
}
