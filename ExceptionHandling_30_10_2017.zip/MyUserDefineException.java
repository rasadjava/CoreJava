package com.c2n.corejava.ExceptionHandling;

public class MyUserDefineException extends Exception {
	MyUserDefineException(){
		System.out.println("This is User defined exception....#");
	}
}
