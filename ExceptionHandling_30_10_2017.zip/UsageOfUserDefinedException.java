package com.c2n.corejava.ExceptionHandling;

public class UsageOfUserDefinedException {

	public static void main(String[] args) throws Exception {
		UsageOfUserDefinedException a = new UsageOfUserDefinedException();
		a.myExceptionMethod(5);
	}

	public void myExceptionMethod(int i) {
		try {
			System.out.println("...Start...");
			if (i == 5) {
				throw new MyUserDefineException();
			}
		} catch (MyUserDefineException e) {
			System.out.println("...End..."+e);
			e.printStackTrace();
		}
	}
	public void myExceptionMethod2(int i) throws Exception {
			System.out.println("...Start...");
			if (i == 5) {
				throw new MyUserDefineException();
			}
			System.out.println("...End...");
	}
}
