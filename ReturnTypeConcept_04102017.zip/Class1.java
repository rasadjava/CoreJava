package com.c2n.corejava.returnTypeUsage;

public class Class1 {
	public int myReturnTypeMehtod(int i, int j) {
		int sum = i + j;
		System.out.println("I belongs to myReturnTypeMethod " + sum);
		return sum;
	}

	public void myNonReturnTypeMethod(int k, int l) {
		int sum = k + l;
		System.out.println("I belongs to myNonReturnTypeMethod " + sum);
	}
}
