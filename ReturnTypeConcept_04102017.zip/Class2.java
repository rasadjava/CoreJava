package com.c2n.corejava.returnTypeUsage;

public class Class2 {

	public static void main(String[] args) {
		Class1 class1 = new Class1();
		class1.myReturnTypeMehtod(1, 2);
		class1.myNonReturnTypeMethod(1, 2);
		System.out.println("One..." + (9 + (class1.myReturnTypeMehtod(1, 2))));
		//System.out.println("Two..." + 9 + (class1.myNonReturnTypeMethod(1, 2)));
	}

}
