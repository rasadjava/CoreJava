package com.c2n.corejava.constructorConcept;

public class ConstructorConceptClass {
	int instantVariable;
	// explicit declaration of default constructor
	ConstructorConceptClass() {
		System.out.println("Default constructor called...");
	}
	// argument constructor
	ConstructorConceptClass(String str, int i) {
		System.out.println("Two Argument constructor called..."+(str+i));
	}
	ConstructorConceptClass(int i, int j) { // can be same number of arguments but should be different data type
		System.out.println(" ##Start## Two Argument constructor called...");
		int sum=i+j;
		int div=i/j;
		int sub=i-j;
		int mul=i*j;
		int rem=i%j;
		instantVariable=i;
		System.out.println(" Sum: "+sum+"\n Division: "+div+"\n Sub: "+sub+"\n Mul: "+mul+"\n Rem: "+rem+"\n instantVariable"+instantVariable);
		System.out.println(" ##End## Two Argument constructor called...");
	}
	
	public void myMethod() {
		System.out.println("Instant variabel value:  "+instantVariable);
	}

	public static void main(String[] args) {
		// creating object for default constructor
		ConstructorConceptClass constructorConceptClass = new ConstructorConceptClass();
		ConstructorConceptClass constructorConceptClassTwoArg = new ConstructorConceptClass("Prasad ",1990);
		ConstructorConceptClass constructorConceptClassTwoArgLogic = new ConstructorConceptClass(9,2);
		//new ConstructorConceptClass(9,1); // this line is valid which executes only the logic wihtin the constructor
		constructorConceptClass.myMethod();
		constructorConceptClassTwoArgLogic.myMethod();
		System.out.println("Value not passed through constructor: "+constructorConceptClass.instantVariable);
		System.out.println("Value passed through arg-constructor: "+constructorConceptClassTwoArgLogic.instantVariable);
		
	}
}
