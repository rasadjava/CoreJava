package com.c2n.corejava.arrays;

public class MyArraysClass {

	public static void main(String[] args) {
		MyArraysClass myArraysClass = new MyArraysClass();
		myArraysClass.mySingleDStaticArray();
		myArraysClass.mySingleDDynamicArray();
		myArraysClass.myTwoDStaticArray();
		myArraysClass.myTwoDDynamiArray();
	}

	public void mySingleDStaticArray() {
		int[] mySingleDIntArray = new int[5];
		mySingleDIntArray[0] = 11;
		mySingleDIntArray[1] = 12;
		mySingleDIntArray[2] = 13;
		mySingleDIntArray[3] = 14;
		mySingleDIntArray[4] = 15;
		System.out.println("Int Array size: " + mySingleDIntArray.length);
		System.out.println("Int Array index: " + mySingleDIntArray[4]);
		for (int i = 0; i < mySingleDIntArray.length; i++) {
			System.out.println("Printing Int Array Values: " + mySingleDIntArray[i]);
		}
	}

	public void mySingleDDynamicArray() {
		String[] mySingleDStringArray = { "A", "B", "C", "D" };
		System.out.println("String Array size: " + mySingleDStringArray.length);
		// System.out.println("String Array index: " + mySingleDStringArray[4]); //
		// ArrayIndexOutOfBoundsException
		for (int i = 0; i < mySingleDStringArray.length; i++) {
			System.out.println("Printing String Array Values: " + mySingleDStringArray[i]);
		}
		// for(String str:mySingleDStringArray) { // for each loop
		// System.out.println("############"+str);
		// }
	}

	public void myTwoDStaticArray() {
		int[][] myTwoDIntArray = new int[3][3];
		myTwoDIntArray[0][0] = 11;
		myTwoDIntArray[0][1] = 12;
		myTwoDIntArray[0][2] = 13;
		myTwoDIntArray[1][0] = 21;
		myTwoDIntArray[1][1] = 22;
		myTwoDIntArray[1][2] = 23;
		// myTwoDIntArray[3][3]=34; will throw ArrayIndexOutOfBounce Exception
		myTwoDIntArray[2][0] = 31;
		myTwoDIntArray[2][1] = 32;
		myTwoDIntArray[2][2] = 33;
		System.out.println("Particular value: " + myTwoDIntArray[0][2]);
		for (int[] integer : myTwoDIntArray) {
			System.out.println("For each content printing..." + integer);
			for (int number1 : integer) {
				System.out.println("nested for each loop printing..." + number1);
			}
		}
	}

	public void myTwoDDynamiArray() {
		String[][] myTwoDStringArray = { { "AA1", "AA2", "AA3" }, { "BB1", "BB2" }, { "CC1", "CC2", "CC3","CC4","CC5" },{ "DD1" } };
	System.out.println("Fetching TwoDimDynamic value: "+myTwoDStringArray[2][0]);
	}
}
