package com.c2n.corejava.inheritance;

public class MyChildClass extends MyParentClass {
	public static void main(String[] args) {
		MyChildClass mcc = new MyChildClass();
		// mcc.printMyString();
		System.out.println(mcc.printMyString());
		mcc.dummyMethod();
		String str = mcc.printDummyMethod();
		System.out.println(str);
		int diff = mcc.addNumber(9, 2) - mcc.mulNumber(1, 1);
		System.out.println(diff);
		System.out.println(mcc.mulStrin("ABC", "123"));
		System.out.println(mcc.addString(1, "9"));

	}

}
