package com.c2n.corejava.inheritance;

public class MyParentClass {
	public String myString = "CoreJava";
	public int number;

	// MyParentClass(String str, int myInt) { // constructor declaration
	// this.myString = str; // assigning the values to global variable
	// this.number = myInt;
	// }

	public String printMyString() {
		String string = "C2N";
		System.out.println(string + "====This is printMyString() method===" + myString);
		return myString;
	}

	public void dummyMethod() {
		System.out.println("I belongs to dummy method");
	}

	public String printDummyMethod() {
		String myString = "stored string";
		return "I belongs to printDummy method " + myString;
	}

	public int addNumber(int i, int j) {
		int sum = i + j;
		return sum;
	}

	public int mulNumber(int l, int k) {
		int mul = l * k;
		return mul;
	}

	public int addString(int i, String s) {
		int ss = Integer.parseInt(s);
		int stringSum = i + ss;
		return stringSum;
	}

	public String mulStrin(String s1, String s2) {
		String str = s1 + s2;
		return str;
	}
}
