package com.c2n.corejava.collections;

import java.util.HashSet;

public class SetInterfaceClass {
	static SetInterfaceClass setInterfaceClass = new SetInterfaceClass();

	public static void main(String[] args) {
		setInterfaceClass.mySetMethod();
	}

	public void mySetMethod() {
		HashSet<String> hashSet = new HashSet<String>();
		hashSet.add("A");
		hashSet.add("A");
		hashSet.add("B");
		hashSet.add("Z");
		hashSet.add("U");
		for (String str : hashSet) {
			System.out.println(str);
		}
	}

}
