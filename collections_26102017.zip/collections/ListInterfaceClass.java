package com.c2n.corejava.collections;

//import java.util.ArrayList;
//import java.util.LinkedList;

import java.util.*;

public class ListInterfaceClass {
	 static ListInterfaceClass listInterfaceClass = new ListInterfaceClass();//
	// instance(global) object declaration

	  ListInterfaceClass() {
			System.out.println("I belongs to default constructor");
			//return "****####****";
		}
	String ListInterfaceClassMethod() {
		System.out.println("I belongs to normal method default constructor");
		return "****####****";
	}

	public static void main(String[] args) {
		// ListInterfaceClass listInterfaceClass = new ListInterfaceClass(); // local
		// object declaration
		listInterfaceClass.myListMethod();
		listInterfaceClass.myGenericListMethod();
	}

	public void myListMethod() {
		// ListInterfaceClass listInterfaceClass=new ListInterfaceClass();
		System.out.println("####Start####");
		ArrayList arrayList = new ArrayList();
		arrayList.add(String.valueOf(1));// here it store int type
		arrayList.add("String"); // here it stores String type
		arrayList.add(new ListInterfaceClass());// here it stores the hashcode of object reference
		arrayList.add(listInterfaceClass.ListInterfaceClassMethod()); // here it stores return value(****####****)
		System.out.println("Fetching value from index 0: " + arrayList.get(0));
		System.out.println("Fetching value from index 1: " + arrayList.get(1));
		System.out.println("Fetching value from index 2: " + arrayList.get(2));
		System.out.println("Fetching value from index 3: " + arrayList.get(3));
		for(Object obj:arrayList) {
			System.out.println(obj);
		}
		System.out.println("####END####");
	}
	
	public void myGenericListMethod() {
		LinkedList<String> linkedList=new LinkedList<String>();
		linkedList.add("B");
		linkedList.add("Z");
		linkedList.add("I");
		linkedList.add("A");
		for(String str:linkedList) {
			System.out.println(str);
		}
	}
}
