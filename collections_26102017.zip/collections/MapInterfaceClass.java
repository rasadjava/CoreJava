package com.c2n.corejava.collections;

import java.util.HashMap;

public class MapInterfaceClass {
	static MapInterfaceClass mapInterfaceClass = new MapInterfaceClass();

	public static void main(String[] args) {
		mapInterfaceClass.myMapMethod();
		mapInterfaceClass.myGenericMapMethod();
	}

	public void myMapMethod() {
		HashMap<String, String> hashMap = new HashMap<String, String>();
		hashMap.put("One", "Mango");
		hashMap.put("Two", "Apple");
		hashMap.put("Three", "Grape");
		hashMap.put("Four", "Banana");
		hashMap.put(null, "NBanana1");
		hashMap.put(null, "NBanana2");
		System.out.println("Fetching value for the key 'three': " + hashMap.get("Three"));
		System.out.println("Fetching value for the key 'Two': " + hashMap.get("Two"));
		for (String str : hashMap.keySet()) {
			System.out.println(str);
			System.out.println(hashMap.get(str));
			System.out.println("###");
		}
	}

	public void myGenericMapMethod() {

		HashMap<Integer, String> hashMap = new HashMap<Integer, String>();
		hashMap.put(1, "Mango");
		hashMap.put(2, "Apple");
		hashMap.put(3, "Grape");
		hashMap.put(4, "Banana");
		hashMap.put(null, "NBanana1");
		hashMap.put(null, "NBanana2");
		System.out.println("Fetching value for the key 'three': " + hashMap.get("Three"));
		System.out.println("Fetching value for the key 'Two': " + hashMap.get("Two"));
		for (Integer i : hashMap.keySet()) {
			System.out.println(i);
			System.out.println(hashMap.get(i));
			System.out.println("$$$");
		}

	}

}
