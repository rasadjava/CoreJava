package com.c2n.corejava.interfaces;

public interface MyInterface2 {

}
