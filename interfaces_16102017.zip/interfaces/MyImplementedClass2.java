package com.c2n.corejava.interfaces;

public class MyImplementedClass2 implements MyInterface {
	public void myAbstractMethod1() {
		System.out.println("MyImplementedClass2.myAbstractMethod1");
	}

	public void myAbstractMethod2() {
		System.out.println("MyImplementedClass2.myAbstractMethod2");
	}

	public static void main(String args[]) {
		// MyImplementedClass myImplementedClass=new MyImplementedClass();
		MyInterface myImplementedClass = new MyImplementedClass();
		MyInterface myImplementedClass2 = new MyImplementedClass2();

		myImplementedClass.myAbstractMethod1();
		myImplementedClass.myAbstractMethod2();

		myImplementedClass2.myAbstractMethod1();
		myImplementedClass2.myAbstractMethod2();

	}
}
