package com.c2n.corejava.interfaces;

public abstract class MyImplementedClass3 implements MyInterface {
abstract void myAbstractMethod(); // the extended class should be provided 
								 //implementation for 3 methods including interfaces methods
}
