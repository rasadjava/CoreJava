package com.c2n.corejava.interfaces;

public class MyImplementedClass implements MyInterface, MyInterface2 { // can achieve multiple inheritance using interfaces
	public void myAbstractMethod1() {
		System.out.println("MyImplementedClass.myAbstractMethod1");
	}

	public void myAbstractMethod2() {
		System.out.println("MyImplementedClass.myAbstractMethod2");
	}
}
