package com.c2n.corejava.interfaces;

public interface MyInterface {
	String myString = "C2N";

	public abstract void myAbstractMethod1();

	void myAbstractMethod2();
// void myAbstractMethod3() {} // should not contain method body or method logic
// private void myAbstractMethod4(); // cannot be used as private its highly restrictice can be used public, abstract, default, static....
   }
