package com.c2n.corejava.variables;

public class StaticVariableUsageInOtherClassWithoutCreatingObject {

	public static void main(String[] args) {
		String ss=InsantLocalStaticVariables.myStaticVariable+"c2n"; // instance variable used without creating object
		System.out.println("Static varible used in other class without creating object: "+ss);
	}

}
