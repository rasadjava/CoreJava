package com.c2n.corejava.variables;
/*
  Variable Rules:
  Instant variables:
 1) All instance variable having default values its optional to assign a value.
 2) this variable can not be used in static method.
 
  Local variables:
 1) this variable need to be initialized, it won't carry default values.
 2) the scope of this variables lies only with in the method or loop or piece of code
 3) this variable only allows final and default modifiers.
 
  Static variables:
 1) this variable belongs to class
 2) this static variables can be used in static and non-static method.
 3) static methods can use only static variables.
 
  */
public class InsantLocalStaticVariables {
	
public int myInstantVariable;// instant variable or Global variable
public static String myStaticVariable="India ";// static variable or class variable

public void myNonStaticMethod() { // non-static method or normal method
	System.out.println("####Non-StaticMethod####");
	 float myLocalVariable=0.0F; // local variable
	 System.out.println("Local variable: "+myLocalVariable);
	 System.out.println("Instance variable: "+myInstantVariable);
	 System.out.println("Static variable used in Non-Static method: "+myStaticVariable);
}

public static void myStaticMethod() { // static method
	System.out.println("####StaticMethod####");
	double mySataticInstantVariable=9.99D;
	//System.out.println(myInstantVariable);// throws error because non-static variable cannot be used in static method
	System.out.println("I belongs to static method: "+myStaticVariable); // static method can use only static variables
	System.out.println("I belongs to static method local variable: "+mySataticInstantVariable);
}

public static void main(String[] args) {
	InsantLocalStaticVariables insantLocalStaticVariables=new InsantLocalStaticVariables();
	insantLocalStaticVariables.myNonStaticMethod();
	myStaticVariable="Hello!";
	InsantLocalStaticVariables.myStaticMethod();
}

}
