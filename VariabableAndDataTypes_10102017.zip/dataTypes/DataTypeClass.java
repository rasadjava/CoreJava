package com.c2n.corejava.dataTypes;

public class DataTypeClass {
	// premitive datatypes
	boolean b;
	char c;
	int i;
	byte by;
	short s;
	long l;
	float f;
	double d;
	// non-premitive datatypes
	String str;

	public static void main(String[] args) {
		DataTypeClass dataTypeClass = new DataTypeClass();
		dataTypeClass.dataTypesDefaultValues();
	}

	public void dataTypesDefaultValues() {
		System.out.println("####premitive dataTypes default values####");
		System.out.println("Boolean: " + b);
		System.out.println("Character: " + c);
		System.out.println("Integer: " + i);
		System.out.println("Byte: " + by);
		System.out.println("Short: " + s);
		System.out.println("Long: " + l);
		System.out.println("Float: " + f);
		System.out.println("Double: " + d);
		System.out.println("####Non-premitive dataTypes default values####");
		System.out.println("String Object: " + str);
	}
}
