package com.c2n.corejava.collections;

import java.util.*;

public class ListInterfaceClass {
	 static ListInterfaceClass listInterfaceClass = new ListInterfaceClass();//
	// instance(global) object declaration

	String ListInterfaceClassMethod() {
		System.out.println("I belongs to normal method default constructor");
		return "****####****";
	}

	public static void main(String[] args) {
		// ListInterfaceClass listInterfaceClass = new ListInterfaceClass(); // local
		// object declaration
		listInterfaceClass.myListMethod();
	}

	public void myListMethod() {
		// ListInterfaceClass listInterfaceClass=new ListInterfaceClass();
		System.out.println("####Start####");
		ArrayList arrayList = new ArrayList();
		arrayList.add(1);// here it store int type
		arrayList.add("String"); // here it stores String type
		arrayList.add(new ListInterfaceClass());// here it stores the hashcode of object reference
		arrayList.add(listInterfaceClass.ListInterfaceClassMethod()); // here it stores return value(****####****)
		System.out.println("Fetching value from index 0: " + arrayList.get(0));
		System.out.println("Fetching value from index 1: " + arrayList.get(1));
		System.out.println("Fetching value from index 2: " + arrayList.get(2));
		System.out.println("Fetching value from index 3: " + arrayList.get(3));
		System.out.println("####END####");
	}
}
