/*
 * The package statement should be on top should not declare any statement on top of package.
 */
package com.c2n.corejava.modifiersUsage;

import com.c2n.corejava.modifiers.AccessModifiers;

public class AccessModifierUsage {

	public static void main(String[] args) {
AccessModifiers accessModifiers = new AccessModifiers();
//System.out.println(accessModifiers.publicInstantVariable); // can be accessed in all packages
//System.out.println(accessModifiers.defaultInstantVariable);// cannot be accessed outside the package
//System.out.println(accessModifiers.privateInstantVariable);// cannot be accessed outside the package
accessModifiers.myPublicMethod();
accessModifiers.myDefaultMethod();
	}

}
