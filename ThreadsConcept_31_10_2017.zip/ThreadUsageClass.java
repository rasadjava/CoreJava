package com.c2n.corejava.Threads;

public class ThreadUsageClass {

	public static void main(String[] args) {
		ThreadUsageClass.myThreadMethod();
	}
	static public void myThreadMethod() {
		Thread t1=new Thread();
		for(int i=0;i<=10;i++) {
			System.out.println("*"+i);
			try {
				t1.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
		}
	}

}
