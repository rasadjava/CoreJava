package com.c2n.corejava.Threads;

import java.io.Serializable;

public class MyRunnableClass implements Runnable {

	public static void main(String[] args) {
		MyRunnableClass myRunnableClass=new MyRunnableClass();
		Thread thread=new Thread(myRunnableClass);
		thread.start();
	}

	@Override
	public void run() {
		System.out.println("I belongs to run method of RunnableI class");
	}

}
