package com.c2n.corejava.Threads;

public class MyThreadClass extends Thread {

	public static void main(String[] args) {
		MyThreadClass myThreadClass =new MyThreadClass();
		myThreadClass.start();
		//myThreadClass.start();
	}
	@Override
	 public void run() {
		 System.out.println("I belongs to run() method of Thread class...");
	 }
}
