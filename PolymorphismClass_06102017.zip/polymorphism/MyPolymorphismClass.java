package com.c2n.corejava.polymorphism;

public class MyPolymorphismClass {
	public static void main(String[] args) {
		MyOverloadedClass myOverloadedClass = new MyOverloadedClass();
		myOverloadedClass.myPolyMorphismMethod(5, " Oct");
		myOverloadedClass.myPolyMorphismMethod(6, " OCT ", 9.45F);
		myOverloadedClass.myPolyMorphismMethod("2017 ", "2018");
		
		System.out.println("#####Overriden method call#####");
		
		MyOverridenClass myOverridenClass = new MyOverridenClass();
		myOverridenClass.myPolyMorphismMethod(100, "Police");
		myOverridenClass.myPolyMorphismMethod1(0, "Hospital");
		myOverridenClass.myPolyMorphismMethod2(1, "Hospital");
		System.out.println(myOverridenClass.myPolyMorphismMethod2(0, "Hospital"));
	}
}
