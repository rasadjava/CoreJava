package com.c2n.corejava.polymorphism;

public class MyOverridenClass extends MyOverloadedClass {
	@Override
	public void myPolyMorphismMethod(int i, String s) { // overriden method with access modifier
		System.out.println("I belongs to accessModifier Overriden myPolyMorphismMethod(arg1,arg2) " + (i + s));
	}

	@Override
	public int myPolyMorphismMethod1(int i, String s) { // overriden method with return type
		System.out.println("I belongs to returnType Overriden myPolyMorphismMethod1(arg1,arg2) " + (i + s));
		return 0;
	}

	@Override
	public int myPolyMorphismMethod2(int i, String s) throws ArithmeticException { // overriden method with exception
		int div = 1 / i;
		System.out.println("I belongs to ExceptionType Overriden myPolyMorphismMethod2(arg1,arg2) " + (i + s));
		return div;
	}
}
