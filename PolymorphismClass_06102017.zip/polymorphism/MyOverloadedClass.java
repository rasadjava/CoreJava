package com.c2n.corejava.polymorphism;

public class MyOverloadedClass {
	public void myPolyMorphismMethod(int i, String s) { // basic method with access modifier
		System.out.println("I belongs to myPolyMorphismMethod(arg1,arg2) " + (i + s));
	}

	public int myPolyMorphismMethod1(int i, String s) { // basic method with return type
		System.out.println("I belongs to myPolyMorphismMethod(arg1,arg2) " + (i + s));
		return 0;
	}

	public int myPolyMorphismMethod2(int i, String s) throws ArithmeticException { // basic method with exception
		System.out.println("I belongs to myPolyMorphismMethod(arg1,arg2) " + (i + s));
		return 0;
	}

	public void myPolyMorphismMethod(int i, String s, float f) {// overloaded method with three args
		System.out.println("I belongs to myPolyMorphismMethod(arg1,arg2,arg3) " + (i + s + f));
	}

	public void myPolyMorphismMethod(String s1, String s2) {// overloaded method with two args
		System.out.println("I belongs to myPolyMorphismMethod(arg1,arg2) " + (s1 + s2));
	}

}
