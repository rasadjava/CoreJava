/*
 * The package statement should be on top should not declare any statement on top of package.
 */
package com.c2n.corejava.modifiersUsage;

import com.c2n.corejava.modifiers.AccessModifiers;

public class AccessModifierUsage extends AccessModifiers {

	public static void main(String[] args) {
		AccessModifiers accessModifiers = new AccessModifiers();
		AccessModifierUsage accessModifierUsage = new AccessModifierUsage();
		// System.out.println(accessModifiers.publicInstantVariable); // can be accessed
		// in all packages
		// System.out.println(accessModifiers.defaultInstantVariable);// cannot be
		// accessed outside the package
		// System.out.println(accessModifiers.privateInstantVariable);// cannot be
		// accessed outside the package
		accessModifiers.myPublicMethod();
		accessModifiers.myDefaultMethod();
		// System.out.println(this.protectedInstanceVariable); // this keyword should
		// not used in static scope.
		accessModifierUsage.protectedUsage();
		accessModifierUsage.staticUsage();
		accessModifierUsage.finalUsage();
	}
	public void protectedUsage() {
		System.out.println("Usage of Protectd Inst Variable " + this.protectedInstanceVariable); // can access only
																									// using 'this'
																									// keyword which
																									// belongs to class
																									// scope
		this.myProtectedMethod(); // can access only using 'this' keyword which belongs to class scope
	}
	public void staticUsage() {
		System.out.println("Usage of static variable: "+AccessModifiers.publicStaticVariable);
		AccessModifiers.myPublicStaticMethod();
	}
	public void finalUsage() {
		AccessModifiers accessModifiers = new AccessModifiers();
		accessModifiers.myPublicFinalMethod();
	}
//	public void myPublicFinalMethod() { // trying to override the final method
//										//cannot override or overload the final method
//	}
}
