package com.c2n.corejava.modifiers;

public class AccessModifiers { // public access modifier class

	/* The following are the access modifiers
	 1) public
	 2) default
	 3) private
	 4) protected
	 */
	/* the following are the non-access modifiers
     1) static
     2) final
     3) abstract
     4) synchronization
..
	*/
	/*
	 this publicInstantVariable can be accessed across all package
	 */
	public int publicInstantVariable=999; // public instance variable
	/*
	 this defaultInstantVariable can be accessed only with in the package
	 */
	int defaultInstantVariable; // default instance variable
	/*
	 this privateInstantVariable can be accessed only with in the class
	 */
	private int privateInstantVariable; // private instance variable
	/*
	 this protectedInstanceVariable can be accessed accross all packages only using inheritance concept
	 */
	protected int protectedInstanceVariable; // protected instance variable
	/*
	 static members can be accessed using class name, not need to create object
	 */
	public static String publicStaticVariable; // public static variable
	static String defaultStaticVariable; // default static variable
	private static String privateStaticVariable; // private static variable
	protected static String protectedStaticVariable; // protected static variable
	
	public void myPublicMethod() { // public method
		publicInstantVariable=100;
		privateInstantVariable=108;
		//System.out.println(privateInstantVariable);
		System.out.println("myPublicMethod "+publicInstantVariable);
	}
	
	public void myDefaultMethod() { // default method
		//public String str="Hai"; //in this local variable declaration only default and final modifiers are allowed
		publicInstantVariable=109;
		System.out.println("myDefaultMethod "+publicInstantVariable);
	}
	
	private void myPrivateMethod() { // private method
		System.out.println("myPrivateMethod");
	}
	
	protected void myProtectedMethod() { // protected method
		System.out.println("myProtectedMethod");
	}
	 
	// static methods with access modifiers
	public static void myPublicStaticMethod() {
		System.out.println("myPublicStaticMethod");
	}
	static void myDefaultStaticMethod() {
		System.out.println("myDefaultStaticMethod");
	}
	private static void myPrivateStaticMethod() {
		System.out.println("myPrivateStaticMethod");
	}
	protected static void myProtectedStaticMethod() {
		System.out.println("myProtectedStaticMethod");
	}
	
	// final methods, where we can not override and overload
	final void myDefaultFinalMethod() {
		System.out.println("myDefaultFinalMethod");
	}
	public final void myPublicFinalMethod() {
		System.out.println("myPublicFinalMethod");
	}
	private final void myPrivateFinalMethod() {
		System.out.println("myPrivateFinalMethod");
	}
	protected final void myProtectedFinalMethod() {
		System.out.println("myProtectedFinalMethod");
	}

}

class AccessModifierTwo{ // default access modifier class, only one class should be public where declaring other class in same class
	public void useDefaultInstantVariable() {
		AccessModifiers accessModifiers = new AccessModifiers();
		System.out.println(accessModifiers.defaultInstantVariable); // can use only in other class of same package
		// System.out.println(accessModifiers.privateInstantVariable); // cannot be used outside the class
	}
	public static void main(String args[]) {}
}
