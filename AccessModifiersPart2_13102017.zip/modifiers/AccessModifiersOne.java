package com.c2n.corejava.modifiers;

public class AccessModifiersOne {
public static void main(String[] args) {
	AccessModifiersOne accessModifiersOne=new AccessModifiersOne();
	accessModifiersOne.myAccessModifiersUsageMethod();
}
	public void myAccessModifiersUsageMethod() {
		AccessModifiers accessModifiers = new AccessModifiers();
		int defaultInstantVariableValue=accessModifiers.defaultInstantVariable; // only accessible in all class of a package
		System.out.println(defaultInstantVariableValue);
		//int privateInstantVariableValue=accessModifiers.privateInstantVariable; // only accessible in same class where it declared
		System.out.println("Protected..."+accessModifiers.protectedInstanceVariable);
	}
}
